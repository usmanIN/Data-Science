# Car-Dekho-Dataset-Prediction-Model

This dataset contains information about used cars listed on <i><strong>cardekho.com</strong></i>
This data can be used for a lot of purposes such as price prediction

#### Header Records of Data Set
<table>
  <thead>
    <tr>
      <th>Car_Name</th>
      <th>	Year</th>
      <th>	Selling_Price</th>
      <th>	Present_Price</th>
      <th>	Kms_Driven</th>
      <th>	Fuel_Type</th>
      <th>	Seller_Type</th>
      <th>	Transmission</th>
      <th>	Owner </th>
    </tr>
  </thead>
  <tbody>
       <tr>
      <td>ritz</td>
      <td>	2014	</td>
      <td>3.35</td>
      <td>	5.59	</td>
      <td>	27000	</td>
      <td>Petrol	</td>
      <td>Dealer</td>
      <td>	Manual</td>
      <td>	0</td>
    </tr>
       <tr>
      <td>sx4</td>
      <td>	2013</td>
      <td>	4.75</td>
      <td>	9.54</td>
      <td>	43000</td>
      <td>	Diesel</td>
      <td>	Dealer</td>
      <td>	Manual</td>
      <td>	0</td>
    </tr>
       <tr>
      <td>ciaz</td>
      <td>	2017</td>
      <td>	7.25</td>
      <td>	9.85</td>
      <td>	6900</td>
      <td>	Petrol</td>
      <td>	Dealer</td>
      <td>	Manual</td>
      <td>	0</td>
    </tr>
       <tr>
      <td>wagon r</td>
      <td>	2011</td>
      <td>	2.85</td>
      <td>	4.15</td>
      <td>	5200</td>
      <td>	Petrol</td>
      <td>	Dealer</td>
      <td>	Manual</td>
      <td>	0</td>
    </tr>
 <tr>
      <td>swift</td>
      <td>2014</td>
      <td>	4.60</td>
      <td>	6.87</td>
      <td>	42450	</td>
      <td>Diesel</td>
      <td>	Dealer</td>
      <td>	Manual</td>
      <td>	0</td>
    </tr>
 
  </tbody>
</table>
    
        

       


