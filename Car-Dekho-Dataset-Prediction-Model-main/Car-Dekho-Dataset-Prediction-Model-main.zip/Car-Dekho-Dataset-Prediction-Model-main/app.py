from flask import Flask, render_template, request
#import jsonify
#import requests
import pickle
import numpy as np
#from sklearn.preprocessing import StandardScaler
import os

app = Flask(__name__)

file = 'model.pkl'
if os.path.exists(file):
    model = pickle.load(open(file,'rb'))
else:
    print("File Don't Exists")    
#    exit()


@app.route('/',methods=['GET'])
def index():
    return render_template("index.html")

@app.route('/predict',methods=['POST'])
def predict():
    
    
    if request.method == "POST":
        Year = int(request.form['Year'])
        Present_Price = float(request.form['Present_Price'])
        Kms_Driven = int(request.form['Kms_Driven'])
        Kms_Driven_log = np.log(Kms_Driven)
        Owner = int(request.form['Owner'])
        Fuel_Type = request.form['Fuel_Type']
        
        if (Fuel_Type == "Petrol"):
            Fuel_Type_Petrol=1
            Fuel_Type_Diesel=0
        elif (Fuel_Type == "Diesel"):
            Fuel_Type_Petrol=0
            Fuel_Type_Diesel=1
        else:
            Fuel_Type_Petrol=0
            Fuel_Type_Diesel=0
            
        Year = 2020 - Year
        
        Seller_Type_Individual = request.form['Seller_Type_Individual']
        if Seller_Type_Individual == "Individual":
            Seller_Type_Individual = 1
        else:
            Seller_Type_Individual = 0
            
            
        Transmission_Manual = request.form['Transmission_Manual']
        if Transmission_Manual == "Manual":
            Transmission_Manual = 1
        else:
            Transmission_Manual = 0

        dslist = [Present_Price,Kms_Driven_log,Owner,Year,Fuel_Type_Diesel,Fuel_Type_Petrol,Seller_Type_Individual,Transmission_Manual]
            
        predict =  model.predict([[Present_Price,Kms_Driven_log,Owner,Year,Fuel_Type_Diesel,Fuel_Type_Petrol,Seller_Type_Individual,Transmission_Manual]])     
        
        result = round(predict[0],2)
        
        if result < 0:
            return render_template('index.html',prediction_texts="Sorry you cannot sell this car")
        else:
            return render_template('index.html',prediction_text=result, dat_list=dslist)

    else:
        return render_template("index.html")



#if __name__=="__main__":
 #   app.run(debug=True)    
